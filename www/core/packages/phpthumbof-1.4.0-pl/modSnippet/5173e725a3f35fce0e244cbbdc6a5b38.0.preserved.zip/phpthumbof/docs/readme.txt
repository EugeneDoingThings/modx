--------------------
Snippet: phpthumbof
--------------------
Created: November 3rd, 2010
Author: Shaun McCormick <shaun@modx.com>
License: GNU GPLv2 (or later at your option)

A custom, secure output filter for phpThumb.

Usage:

[[+imageUrl:phpthumb=`w=234&h=123&zc=1`]]

Any phpThumb-compatable config options can be passed into the filter.

Thanks for using phpThumbOf!
Shaun McCormick
shaun@modx.com